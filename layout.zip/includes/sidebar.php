<div class="sidebar">
    <ul>
        <li class="accordion-item"> 
            <a href="../templates/accommodation_info.php">Thông tin lưu trú</a>
        </li>
        <li>
            <a href="../templates/manage_buildings.php">Quản lý toà nhà</a>
        </li>
        <?php if (isset($_SESSION['role']) && in_array($_SESSION['role'],['manager','admin'])): ?>
        <li>
            <a href="../templates/pending_buildings.php">Toà nhà chưa duyệt</a>
        </li>
        <?php endif; ?>
        <li class="accordion-item">
            <a href="javascript:void(0)" class="accordion-toggle">Doanh thu</a>
            <div class="accordion-content">
                <a href="../templates/sales.php">Doanh thu Sale</a>
                <a href="../templates/managers.php">Quản lý</a>
            </div>
        </li>
        <li><a href="../templates/manage_contract.php">Hợp đồng</a></li>
        <li><a href="../templates/manage_contract.php?new=1">Hợp đồng mới</a></li>
        <?php if (isset($_SESSION['role']) && in_array($_SESSION['role'],['manager','admin'])): ?>
        <li><a href="../templates/manage_users.php">Quản lý người dùng</a></li>
        <li><a href="../templates/post.php">Đăng bài</a></li>
        <?php endif; ?>
    </ul>
</div>
